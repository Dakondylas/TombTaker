#Idris Sampson
#4/16/24
#function the begging of the end for our fearless acheologist
import questionBank
import random


def puzzle(race, gender, hair_color, name):
   key1 = 1
   key2 = 1
   key3 = 1
   question_counter = 1
   grade_list = []
   puzzle_bank = [1, 2, 3]
   # Makes sure that you dont get the same type of encounter twice in a row
   order_checker = "notEnchantress"
   while True:

      # all the code below, randomizer that will pick wether you take a quiz path or secret-idris
      chooser = random.randint(1, 100)
      if order_checker == "notEnchantress":
         if key1 == 1:
            if chooser == 55:
               from question1 import quiz_puzzle
               key1-=1
               order_checker = "Enchantress"
         if key1 != 1:
            if order_checker == "notEnchantress":
               if chooser == 2:# this picks out the question - idris
                  from Rand import secrets
                  from YunusPuzzles import puzzle_chooser
                  currentPuzzle = random.choice(puzzle_bank)
                  puzzle_chooser(currentPuzzle, race, gender, hair_color, name)
                  puzzle_bank.remove(currentPuzzle)
                  key1-=1
                  order_checker = "Enchantress"
      else:
         if key1 != 1:
            if chooser == 88:
               if len(grade_list) != 9:
                  questionBank.story(grade_list)
                  for x in range(3):
                     questionBank.getQuestion(grade_list)
                     order_checker = "notEnchantress"
               else:
                  key3-=1

      if key1 == -3 and key3 == -1:
         import DefeatandVictory
         input("\nPress enter for final grade...\n")
         if questionBank.final_grading(grade_list):
            DefeatandVictory.vicScreen()
         else:
            DefeatandVictory.deadscreen()
         quit()



