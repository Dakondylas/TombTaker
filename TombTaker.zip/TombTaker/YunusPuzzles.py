# Team 2 Project - " Tomb Taker"
# By Dillon, Idris and Yunus
# 4/19/2024
# Puzzles made by Yunus for the main and moving text
import time #  Importing time module
def moving_text(text):  # This function allows text to print at a reading pace
    for letter in text:
        print(letter, end="", flush=True)
        time.sleep(0.02)
        
def puzzle1(race, gender, hair_color, name):  # First puzzle
    # True or false question
    print("\n\nWhen the sand storm dissipates again you realize a clearing has \nopened up past the pressure plates\nYou continue through the opened clearing and before you lies the snake but only 2 pressure plates this time")
    print("The snake redirects your attention to an enscribed tablet cemented in the wall with an age old question that\nhas since baffled archiologists and historians alike...")
    print("I am not able to extend my abilities through the tablet, you will only have one chance to answer it...")
    input("\n\nPress enter to hear the age old question...")
    moving_text("\n\"Batman is good at python\"\n")  # Receiving input from question
    moving_text("Is it true? [1], or false?[2]?\n")
    Q1 = input("\n")
    if Q1.lower() == '1' or Q1.lower() == "true":
        print("\n\"Correct move to the right pressure plate\", you walk to the right pressure plate and nothing happens at first...")
    else:
        print("\n\n\"You failed... Die!\"")
        import DefeatandVictory
        DefeatandVictory.deadscreen(race, gender, hair_color, name)
        quit()
 # Calls puzzle1

# Puzzle2
# True or false question
def puzzle2(race, gender, hair_color, name):
    print("\n\nWhen the sand storm dissipates again you realize a clearing has \nopened up past the pressure plates\nYou continue through the opened clearing and once again stand before the snake and 2 pressure plates")
    print("The snake asks you another question to move on...\n\nA subnet mask is used to determine\nthe network portion and the host portion of an IP address.\nIs this true? [1] Yes [2] No: ")
    # Asks question and gets input
    # Checks answer
    Q1 = input("\n")
    if Q1.lower() == '1' or Q1.lower() == "true":
        print(
            "\n\"Correct move to the right pressure plate\", you walk to the right pressure plate and nothing happens at first...")
    else:
        print("\n\n\"You failed... Die!\"")
        import DefeatandVictory
        DefeatandVictory.deadscreen(race, gender, hair_color, name)
        quit()
def puzzle3(race, gender, hair_color, name):
    # Puzzle 3
        #Simplest puzzle for MVP
    print(
        "\n\nWhen the sand storm dissipates again you realize a clearing has \nopened up past the pressure plates\nYou continue through the opened clearing and once again stand before the snake and 2 pressure plates")
    print("The snake asks you another question to move on...\n\nDoes DNS (Domain Name System) translate domain names into IP addresses?\n [1] Yes [2] No: ")
    # Asking question
    Q1 = input("\n")
    # Checking user input
    if Q1.lower() == '1' or Q1.lower() == "true":
        print(
            "\n\"Correct move to the middle pressure plate\", you walk to the middle pressure plate and nothing happens at first...")
        input("Press enter to continue...")
    else:
        print("\n\n\"You failed... Die!\"")
        import DefeatandVictory
        DefeatandVictory.deadscreen(race, gender, hair_color, name)
        quit()


# Allows us to call any puzzle from another module
def puzzle_chooser(num, race, gender, hair_color, name):
    if num == 1:
        puzzle1(race, gender, hair_color, name)
    elif num == 2:
        puzzle2(race, gender, hair_color, name)
    elif num == 3:
        puzzle3(race, gender, hair_color, name)
