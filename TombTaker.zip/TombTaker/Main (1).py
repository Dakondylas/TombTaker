#Idris Sampson
#4/16/24
#main function the begging of the end for our fearless acheologist
#get player input and desired race of choice made by idris
from TitleScreen import *
# from Soundtest import Voicelines

print('You are a fearless archaeologist who begins his adventure  with his friends by venturing to Egypt to enter the tomb of King Ramesses.')
character_customized = input("Would you like to customise your character? (Y/N)\n(Census data will be collected on customisation and victory status for further analysis)\n")
print("\n\n")
if character_customized.lower() == "y" or character_customized.lower() == "yes":
    print('\033[1mCharacter customization\033[0m')
    player = input("what is your name:\n")
    player = f"Name: {player}"
    race = input("Race:\n")
    race = f"Race {race}"
    gender = input("Gender?\n")
    gender = f"Gender: {gender}"
    hair_color = input("Hair Color?\n")
    hair_color = f"Hair Color: {hair_color}"
    print("\nThank you for the data, data will not be saved until end of game...")
    input("Press enter to continue...")

else:
    player = "Name: N/A"
    race = "Race: N/A"
    gender = "Gender: N/A"
    hair_color = "Hair Color: N/A"
    print("That's ok! enjoy the game!")
    input("Press enter to continue...")

print("\n" * 10)
print("You and your friends Stephanie and Todd bust open the door to the tomb, as you guys fully open the tomb a huge gust of wind carrying a  ton of sand and dust"'\n'"comes flying out from the inside of the tomb, and from the bowels of it you hear “Turn back now or face my curse” *in an echoing taunt*"'\n\n'"Despite the clear warnings you provide because you know what you could gain if you successfully tomb taker this a flood of wealth, fame and power will"'\n'"engulf your every being, so yall enter the tomb.")
# x = Voicelines
#x.play(x, x.IntroTomb1)
#x.play(x,x.TurnBackNowMonster)

print("As you guys further deeper into the tomb Todd begins to get hesitant due to the creepy event unfloding such as creepy noises and huge spider and this \nisnt Australia and dashes to the exit like a titan from AOT with his hands flailing left and right.")
print(" ")
trick_rooni = input("Would you like to leave with him (yes or no) ")
while trick_rooni.lower() != "y" and trick_rooni.lower() != "yes" and trick_rooni.lower() != "n" and trick_rooni.lower() != "no":
    trick_rooni = input("Would you like to leave with him (yes or no) ")
print("\n" * 10)
if trick_rooni.lower() == 'yes' or trick_rooni.lower() == "y":
    print("\n\nYou grab onto Stephanie’s arm and also begin to make a mad dash to the exit then the door suddenly shuts right infront Todd almost crushing him\n These events are almost like the entity doesn't want y'all to leave.")
    from Puzzle import puzzle
    puzzle(race, gender, hair_color, player)
elif trick_rooni.lower() == 'no' or trick_rooni.lower() == "n":
    print("\n\nAs your narrarator I would have suggested running with Todd but now it is to late."'\n'"You decided not to run away with Todd so he was able to escape while you and Stephanie continued down the tomb."'\n'"Then yall remebered Todd had all the food so yall died")
    input("\n\nPress enter...")
    import DefeatandVictory
    DefeatandVictory.deadscreen(race, gender, hair_color, player)

