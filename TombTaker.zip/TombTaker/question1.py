#Idris Sampson
#4/16/24
#this quetions the user and chooses there path depending on choice
def quiz_puzzle(race, gender, hair_color, name):
    print("\n\nYou, Todd and Stephanie come across a long room, you can see a lever on the other end of the room and you look at the ground and see 3 pressure plates...")
    print("Todd points out that those are definatly boobie traps and yall should proceed with caution.\n\nThen a ghostly figure of a snake decends from the heavens")
    print("The snake says in a heavenly voice \"Anwser my question correctly and you get to move on\" ")
    print("I am feeling gracious today and will grant you three chances for this first question, however I will no longer protect you\nfarther into the tomb\n")
    print("Stephanie looks prepared and ready then yells \"Bring it on you stinky gucci bag!!\" ")
    input("\nPress enter to continue...\n\n")
    print("\n" * 10)
    #this code ask the user for an awnser and if incorrrect put them though a loop only giving them 3 chances- idris
    x = 3
    while True:
        print("The snake utters:")
        Q1 = input("\nWhat part of the random module is inclusive:\n")

        if Q1.lower() == 'randint':
            print("\n \"Correct move to the left pressure plate\", you walk to the left pressure plate which is in front of a blank wall and nothing happens at first...")
            input("Press enter...")
            break
        elif Q1.lower() !='randint':
            print("\n \"Incorrect...\" The sly snake said...")
            x -= 1
            print(f'You have {x} guesses left\n\n')
        if x == 0:
            print("\n\n\"You failed... Die!\"")
            import DefeatandVictory
            DefeatandVictory.deadscreen(race, gender, hair_color, name)
            quit()

