# Team 2 Project - " Tomb Taker"
# By Dillon, Idris and Yunus
# 4/19/2024
# Puzzles made by Yunus for the main and moving text
import time #  Importing time module
def moving_text(text):  # This function allows text to print at a reading pace
    for letter in text:
        print(letter, end="", flush=True)
        time.sleep(0.02)
        
def puzzle1(race, gender, hair_color, name):  # First puzzle
# True or false question
    moving_text("""You notice a tablet asking you...\n \"is batman good at python\"""")  # Receiving input from question
    moving_text("Is it true? [1], or false?[2]?\n")
    Choice = input()
    if Choice == "1":  #Checking if correct
        moving_text("\nCorrect!\n")

    else:
        print("\nWrong\n")
        import DefeatandVictory
        DefeatandVictory.deadscreen()
        x = DefeatandVictory.Rating(False, race, gender, hair_color, name)
        x.review()
        quit()
 # Calls puzzle1

# Puzzle2
# True or false question
def puzzle2(race, gender, hair_color, name):
    var = input("\n\nA voice from below asks you...\nA subnet mask is used to determine\nthe network portion and the host portion of an IP address.\nIs this true? [1] Yes [2] No: ").lower() # Asks question and gets input
    while var != "1":
        if var == "2":
            break
        moving_text("\nPlease input 1 or 2: ") # Checks answer
    if var == "1":
        print("\nCorrect!\n")
        input("Press enter to continue...")
    if var == "2":
        print("\nWrong\n")
        input("Press enter...")
        import DefeatandVictory
        DefeatandVictory.deadscreen()
        x = DefeatandVictory.Rating(False, race, gender, hair_color, name)
        x.review()
        quit()
def puzzle3(race, gender, hair_color, name):
    # Puzzle 3
        #Simplest puzzle for MVP
    var = input("\n\nA voice from below asks you...\nDoes DNS (Domain Name System) translate domain names into IP addresses?\n [1] Yes [2] No: ").lower()  # Asking question
    if var == "1": # Checking user input
        print("\nCorrect!\n")
        input("Press enter to continue...")
    if var == "2":
        print("\nWrong\n")
        input("Press enter to continue...")
        import DefeatandVictory
        DefeatandVictory.deadscreen()
        x = DefeatandVictory.Rating(False, race, gender, hair_color, name)
        x.review()
        quit()


# Allows us to call any puzzle from another module
def puzzle_chooser(num, race, gender, hair_color, name):
    if num == 1:
        puzzle1(race, gender, hair_color, name)
    elif num == 2:
        puzzle2(race, gender, hair_color, name)
    elif num == 3:
        puzzle3(race, gender, hair_color, name)
